package com.reserva;

import com.reserva.morador.Espacos;
import com.reserva.morador.EspacosRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import java.util.Optional;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(value = false)
public class EspacosRepositoryTests {
    @Autowired private EspacosRepository repo;

    @Test
    public void testAddNew(){
        Espacos espacos = new Espacos();
        espacos.setNome("Jacinto");

        Espacos savedEspacos = repo.save(espacos);

        Assertions.assertNotNull(savedEspacos);
        Assertions.assertTrue(savedEspacos.getId() > 0);
    }

    @Test
    public void testListAll(){
        Iterable<Espacos> carros = repo.findAll();
        assert carros != null;
        for (Espacos espacos : carros){
            System.out.println(espacos);
        }
    }
    @Test
    public void testUpdate(){
        Integer carroId = 1;
        Optional<Espacos> optionalCarro = repo.findById(carroId);
        Espacos espacos = optionalCarro.get();
        espacos.setNome("Jacinto Junior");
        repo.save(espacos);
    }
    @Test
    public void testGet() {
        Integer carroId = 3;
        Optional<Espacos> optionalCarro = repo.findById(carroId);
        assert optionalCarro.isPresent();
        System.out.println(optionalCarro.get());
    }
    @Test
    public void testDelete(){
        Integer carroId = 3;
        repo.deleteById(carroId);

        Optional<Espacos> optionalCarro = repo.findById(carroId);
        assert optionalCarro.isEmpty();
    }
}