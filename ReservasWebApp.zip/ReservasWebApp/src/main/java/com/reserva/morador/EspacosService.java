package com.reserva.morador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EspacosService {
    @Autowired private EspacosRepository repo;

    public List<Espacos> listAll() {
        return (List<Espacos>) repo.findAll();
    }

    public void save(Espacos espacos) {
        repo.save(espacos);
    }
    public Espacos get(Integer id) throws EspacosNotFoundException {
        Optional<Espacos> result = repo.findById(id);

        if(result.isPresent()) {
            return result.get();
        }
        throw new EspacosNotFoundException("Espacos não encontrado pelo ID " + id);
    }
    public void delete(Integer id) throws EspacosNotFoundException {
        Long count = repo.countById(id);
        if(count == null || count == 0) {
            throw new EspacosNotFoundException("Espacos não encontrado pelo ID " + id);

        }
        repo.deleteById(id);
    }
}
