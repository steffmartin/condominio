package com.reserva.morador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.bind.annotation.ModelAttribute;
import java.util.List;
import java.util.Arrays;

@Controller
public class EspacosController {
    @Autowired private EspacosService service;

    @ModelAttribute("diaSemanaList")
    public List<DiaSemana> getDiaSemanaList() {
        return Arrays.asList(DiaSemana.values());
    }
    @ModelAttribute("turnoList")
    public List<Turno> getTurnoList() {
        return Arrays.asList(Turno.values());
    }

    @GetMapping("/menu/tabelaEspacos")
    public String showEspacosList(Model model) {
        List<Espacos> listEspacos = service.listAll();
        model.addAttribute("listEspacos", listEspacos);
        return "tabelaEspacos"; //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
    }

    @GetMapping("/menu")
    public String showMenu(Model model) {
        return "menu"; //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
    }

    @GetMapping("/menu/registrar-espaco")
    public String showNewForm(Model model) {
        model.addAttribute("espacos", new Espacos());
        model.addAttribute("pageTitle", "CADASTRO DE ESPAÇOS");
        return "cadastro"; // REFERENCIA AO ARQUIVO HTML QUE CRIA MORADORES
    }

    @PostMapping("/menu/salvar-espaco")
    public String saveEspacos(Espacos espacos, RedirectAttributes ra) {
        service.save(espacos);
        ra.addFlashAttribute("message", "Espacos salvo no banco de dados");
        return "redirect:/menu";  //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
    }
    @GetMapping("/menu/editar-espaco/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model, RedirectAttributes ra) {
        try {
            Espacos espacos = service.get(id);
            model.addAttribute("espacos", espacos);
            model.addAttribute("pageTitle", "Editar Espacos (ID:" + id + ")");
            return "cadastro";  //REFERENCIA AO ARQUIVO HTML QUE CRIA ESPACOS
        } catch (EspacosNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
            return "redirect:/menu"; //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
        }
    }

    @GetMapping("/menu/remover-espaco/{id}")
    public String deleteEspacos(@PathVariable("id") Integer id, RedirectAttributes ra) {
        try {
            service.delete(id);
            ra.addFlashAttribute("message", "O carro com ID: " + id + " foi removido do banco de dados");
        } catch (EspacosNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
        }
        return "redirect:/menu/tabelaEspacos";  //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
    }
}

