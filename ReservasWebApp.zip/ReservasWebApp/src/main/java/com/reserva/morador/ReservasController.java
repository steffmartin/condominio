package com.reserva.morador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class ReservasController {
    @Autowired private ReservasService service;
    @Autowired private EspacosService espacosService;


    @ModelAttribute("espacoList")
    public List<Espacos> getEspacosList() {
        return espacosService.listAll();
    }

    @ModelAttribute("turnoList")
    public List<Turno> getTurnoList() {
        return Arrays.asList(Turno.values());
    }

    @GetMapping("/menu/tabelaReservas")
    public String showReservasList(Model model) {
        List<Reservas> listReservas = service.listAll();
        model.addAttribute("listReservas", listReservas);
        return "tabelaReservas"; //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
    }

    @GetMapping("/menu/registrar-reserva")
    public String showNewForm(Model model) {
        model.addAttribute("reservas", new Reservas());
        model.addAttribute("pageTitle", "FAZER RESERVAS");
        return "cadastroReservas"; // REFERENCIA AO ARQUIVO HTML QUE CRIA MORADORES
    }

    @PostMapping("/menu/salvar-reserva")
    public String saveReservas(Reservas reservas, RedirectAttributes ra) {
        service.save(reservas);
        ra.addFlashAttribute("message", "Reservas salvo no banco de dados");
        return "redirect:/menu";  //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
    }
    @GetMapping("/menu/editar-reserva/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model, RedirectAttributes ra) {
        try {
            Reservas reservas = service.get(id);
            model.addAttribute("reservas", reservas);
            model.addAttribute("pageTitle", "Editar Reservas (ID:" + id + ")");
            return "cadastroReservas";  //REFERENCIA AO ARQUIVO HTML QUE CRIA RESERVAS
        } catch (ReservasNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
            return "redirect:/menu"; //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
        }
    }

    @GetMapping("/menu/remover-reserva/{id}")
    public String deleteReservas(@PathVariable("id") Integer id, RedirectAttributes ra) {
        try {
            service.delete(id);
            ra.addFlashAttribute("message", "O carro com ID: " + id + " foi removido do banco de dados");
        } catch (ReservasNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
        }
        return "redirect:/menu";  //REFERENCIA AO ARQUIVO HTML MENU PRINCIPAL
    }
}

