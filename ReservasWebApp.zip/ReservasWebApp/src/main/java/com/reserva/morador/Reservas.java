package com.reserva.morador;

import jakarta.persistence.*;

@Entity
@Table(name = "reservas")
public class Reservas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false, length = 40)
    private String nomeEspaco;
    @Column(nullable = false, length = 40)
    private String nomePessoa;
    @Column(nullable = false, length = 40)
    private String cpf;
    @Column(nullable = false, length = 3)
    private Integer quantPessoas;
    @Column(nullable = false)
    private Turno turno;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomeEspaco() {
        return nomeEspaco;
    }

    public void setNomeEspaco(String nomeEspaco) {
        this.nomeEspaco = nomeEspaco;
    }

    public String getNomePessoa() {
        return nomePessoa;
    }

    public void setNomePessoa(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Integer getQuantPessoas() {
        return quantPessoas;
    }

    public void setQuantPessoas(Integer quantPessoas) {
        this.quantPessoas = quantPessoas;
    }

    public Turno getTurno() {
        return turno;
    }

    public void setTurno(Turno turno) {
        this.turno = turno;
    }
}