package com.reserva.morador;

public class ReservasNotFoundException extends Throwable {
    public ReservasNotFoundException(String message) {
        super(message);
    }
}
