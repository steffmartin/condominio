package com.reserva.morador;

import org.springframework.data.repository.CrudRepository;

public interface EspacosRepository extends CrudRepository<Espacos, Integer> {
    public Long countById(Integer id);
}
