package com.reserva.morador;

public class EspacosNotFoundException extends Throwable {
    public EspacosNotFoundException(String message) {
        super(message);
    }
}
