package com.reserva.morador;

public enum Turno {

    MANHA(1, "Manhã"),
    TARDE(2, "Tarde"),
    NOITE(3, "Noite");

    private final int codigo;
    private final String nome;

    private Turno(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }
    public String getNome() {
        return nome;
    }
}
