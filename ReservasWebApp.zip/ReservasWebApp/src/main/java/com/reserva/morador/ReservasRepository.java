package com.reserva.morador;

import org.springframework.data.repository.CrudRepository;

public interface ReservasRepository extends CrudRepository<Reservas, Integer> {
    public Long countById(Integer id);
}
